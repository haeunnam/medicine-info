function PageNotFound() {
  return <div>404 페이지를 찾을 수가 없습니다.</div>;
}

export default PageNotFound;
