import useInput from "../../../hooks/useInput";
import DeactivateTemplate from "../../../components/templates/DeactivateTemplate";
import { request } from "../../../api";
import { useHistory } from "react-router-dom";
import { useSelector } from 'react-redux'
import {
  nicknameValidator,
} from "../../../validator";

function Deactivate() {
  const history = useHistory();
  const userObj =  useSelector(state => state.userReducer.userInfo);
  const nickname = useInput(userObj.nickname, nicknameValidator);

  function validCheck() {
    // radio button 체크 여부 확인
    // if () {
    //   alert("탈퇴 안내 확인 여부를 체크해주세요");
    //   return false;
    // }
    return true;
  }

  async function handleUserDeactivate() {
    //탈퇴 안내 체크 확인
    const valid = validCheck();
    if (!valid) return;

    //backend에 REST DELETE 요청으로 구현 돼있네
    // const response = await request("DELETE", "/users/Deactivate", data);
    const response = await request("DELETE", "/users/deactivate");
    if (response.isSuccess) {
      localStorage.removeItem("loginUser");
      alert("정상적으로 탈퇴되었습니다. 그동안 이용해주셔서 감사합니다.");
      history.replace({ pathname: "/" });
    } else {
      alert("탈퇴에 실패했습니다.")
    }
  }

  return (
    <>
      <DeactivateTemplate
        nickname={nickname}
        handleUserDeactivate={handleUserDeactivate}
      />
    </>
  );
}

export default Deactivate;
