import React from "react";
import { FormContainer, WarningContainer } from "./styles";
import Header from "../../molecules/Header";
import FooterButton from "../../atoms/FooterButton";
// import Label from "../../atoms/Label";

function DeactivateTemplate({
  nickname,
  handleUserDeactivate,
}) {
  return (
    <>
      <Header title="회원탈퇴" isBack />
      <FormContainer>
        <div className="input-box">
            {nickname.value} 님
        </div>
        그동안 이게뭐약 서비스를 이용해 주셔서 감사합니다.
      </FormContainer>
      <WarningContainer>
        <div>
          탈퇴 시, 이게뭐약에서 저장한 내역은 모두 삭제되며, 탈퇴 이후 복구가 불가능합니다.
        </div>
        <div>
          작성된 리뷰는 자동 삭제되지 않습니다. 이를 원치 않을 경우 작성한 리뷰를 모두 삭제하신 후 탈퇴해주세요.
        </div>
        
      </WarningContainer>
      <FooterButton children="회원탈퇴" onClick={() => handleUserDeactivate()} />
    </>
  );
}

export default DeactivateTemplate;
