create table my_medicine
(
    id          int auto_increment comment '복용 번호'
        primary key,
    user_id     int                                 not null comment '유저 번호',
    medicine_id varchar(9)                          not null comment '약 번호',
    datetime    date                                not null comment '복용시작일자',
    created_at  timestamp default CURRENT_TIMESTAMP not null comment '등록일자',
    updated_at  timestamp                           null on update CURRENT_TIMESTAMP comment '수정일자',
    constraint FK_my_medicine_medicine_id_medicine_id
        foreign key (medicine_id) references medicine (id)
            on delete cascade,
    constraint FK_my_medicine_user_id_user_id
        foreign key (user_id) references user (id)
            on delete cascade
)
    comment '유저가 복용중인 약 관리';

INSERT INTO wtm.my_medicine (id, user_id, medicine_id, datetime, created_at, updated_at) VALUES (3, 22, '195900034', '2021-10-03', '2021-10-03 23:26:30', '2021-10-03 23:26:30');
INSERT INTO wtm.my_medicine (id, user_id, medicine_id, datetime, created_at, updated_at) VALUES (5, 22, '195900043', '2021-10-04', '2021-10-04 01:57:42', '2021-10-04 01:57:42');
INSERT INTO wtm.my_medicine (id, user_id, medicine_id, datetime, created_at, updated_at) VALUES (30, 36, '199900216', '2003-09-18', '2021-10-05 02:35:40', '2021-10-05 02:35:40');
INSERT INTO wtm.my_medicine (id, user_id, medicine_id, datetime, created_at, updated_at) VALUES (34, 36, '201401876', '2021-09-26', '2021-10-05 02:37:13', '2021-10-05 02:37:13');
INSERT INTO wtm.my_medicine (id, user_id, medicine_id, datetime, created_at, updated_at) VALUES (36, 36, '200809325', '2021-09-26', '2021-10-05 02:37:32', '2021-10-05 02:37:32');
INSERT INTO wtm.my_medicine (id, user_id, medicine_id, datetime, created_at, updated_at) VALUES (37, 36, '201902545', '2021-09-26', '2021-10-05 02:38:05', '2021-10-05 02:38:05');
INSERT INTO wtm.my_medicine (id, user_id, medicine_id, datetime, created_at, updated_at) VALUES (38, 36, '195700020', '2021-10-05', '2021-10-05 02:38:21', '2021-10-05 02:38:21');
INSERT INTO wtm.my_medicine (id, user_id, medicine_id, datetime, created_at, updated_at) VALUES (39, 23, '196600012', '2021-10-05', '2021-10-05 10:11:22', '2021-10-05 10:11:22');
INSERT INTO wtm.my_medicine (id, user_id, medicine_id, datetime, created_at, updated_at) VALUES (40, 33, '198601346', '2021-10-05', '2021-10-05 13:57:18', '2021-10-05 13:57:18');
INSERT INTO wtm.my_medicine (id, user_id, medicine_id, datetime, created_at, updated_at) VALUES (44, 33, '201500053', '2021-10-05', '2021-10-05 20:30:28', '2021-10-05 20:30:28');
INSERT INTO wtm.my_medicine (id, user_id, medicine_id, datetime, created_at, updated_at) VALUES (45, 33, '200500548', '2021-10-05', '2021-10-05 20:49:12', '2021-10-05 20:49:12');
INSERT INTO wtm.my_medicine (id, user_id, medicine_id, datetime, created_at, updated_at) VALUES (46, 23, '199303109', '2021-10-06', '2021-10-06 16:39:00', '2021-10-06 16:39:00');
INSERT INTO wtm.my_medicine (id, user_id, medicine_id, datetime, created_at, updated_at) VALUES (47, 23, '195700020', '2021-10-06', '2021-10-06 17:05:55', '2021-10-06 17:05:55');
INSERT INTO wtm.my_medicine (id, user_id, medicine_id, datetime, created_at, updated_at) VALUES (48, 23, '201109654', '2021-10-06', '2021-10-06 17:38:35', '2021-10-06 17:38:35');