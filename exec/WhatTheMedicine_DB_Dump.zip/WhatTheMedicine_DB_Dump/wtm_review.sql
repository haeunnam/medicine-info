create table review
(
    id          int auto_increment comment '리뷰 번호'
        primary key,
    user_id     int                                 not null comment '유저 번호',
    medicine_id varchar(9)                          not null comment '약 번호',
    score       int                                 not null comment '리뷰 점수',
    content     text                                not null comment '리뷰 내용',
    created_at  timestamp default CURRENT_TIMESTAMP not null comment '리뷰 생성일',
    updated_at  timestamp                           null on update CURRENT_TIMESTAMP comment '리뷰 수정일',
    constraint FK_review_medicine_id_medicine_id
        foreign key (medicine_id) references medicine (id)
            on delete cascade,
    constraint FK_review_user_id_user_id
        foreign key (user_id) references user (id)
            on delete cascade
)
    comment '유저가 쓴 리뷰 관리';

INSERT INTO wtm.review (id, user_id, medicine_id, score, content, created_at, updated_at) VALUES (6, 22, '195700020', 2, '그냥2', '2021-10-04 13:04:18', '2021-10-04 04:13:04');
INSERT INTO wtm.review (id, user_id, medicine_id, score, content, created_at, updated_at) VALUES (7, 21, '195700020', 3, '그냥2', '2021-10-04 13:04:40', '2021-10-04 13:04:40');
INSERT INTO wtm.review (id, user_id, medicine_id, score, content, created_at, updated_at) VALUES (8, 21, '196600011', 3, '그냥2', '2021-10-04 13:10:11', '2021-10-04 13:10:11');
INSERT INTO wtm.review (id, user_id, medicine_id, score, content, created_at, updated_at) VALUES (9, 23, '201401143', 1, 'ds', '2021-10-04 19:43:22', '2021-10-04 19:43:22');
INSERT INTO wtm.review (id, user_id, medicine_id, score, content, created_at, updated_at) VALUES (10, 23, '200905903', 3, 'ㅅㅈㄷㄹ', '2021-10-04 19:47:40', '2021-10-04 19:47:40');
INSERT INTO wtm.review (id, user_id, medicine_id, score, content, created_at, updated_at) VALUES (11, 23, '200302005', 2, '좋았습니다', '2021-10-04 19:50:18', '2021-10-04 19:50:18');
INSERT INTO wtm.review (id, user_id, medicine_id, score, content, created_at, updated_at) VALUES (12, 23, '197400262', 3, '좋아요', '2021-10-04 19:50:43', '2021-10-04 19:50:43');
INSERT INTO wtm.review (id, user_id, medicine_id, score, content, created_at, updated_at) VALUES (13, 23, '200808195', 3, 'ㅎㅎㅎㅎㅎ', '2021-10-04 19:51:04', '2021-10-04 19:51:04');
INSERT INTO wtm.review (id, user_id, medicine_id, score, content, created_at, updated_at) VALUES (14, 23, '200804447', 3, 'ㅎㅎㅎㅎ', '2021-10-04 19:52:01', '2021-10-04 19:52:01');
INSERT INTO wtm.review (id, user_id, medicine_id, score, content, created_at, updated_at) VALUES (28, 23, '196600011', 5, 'ㅎㅎㅎㅎㅎㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ', '2021-10-04 22:18:11', '2021-10-04 22:18:29');
INSERT INTO wtm.review (id, user_id, medicine_id, score, content, created_at, updated_at) VALUES (29, 28, '195700020', 3, 'ㅎㅎㅎㅎㅎㅎ', '2021-10-04 22:20:49', '2021-10-04 22:20:49');
INSERT INTO wtm.review (id, user_id, medicine_id, score, content, created_at, updated_at) VALUES (31, 33, '195700020', 3, 'gggggggggggggg', '2021-10-04 22:22:29', '2021-10-04 22:22:29');
INSERT INTO wtm.review (id, user_id, medicine_id, score, content, created_at, updated_at) VALUES (32, 36, '195700020', 3, 'gg', '2021-10-04 22:24:35', '2021-10-04 22:24:35');
INSERT INTO wtm.review (id, user_id, medicine_id, score, content, created_at, updated_at) VALUES (33, 21, '200001368', 5, '먹고 금방 나았어요!', '2021-10-05 13:12:42', '2021-10-05 13:12:42');