create table user
(
    id         int auto_increment comment '유저 번호'
        primary key,
    email      varchar(45)                         not null comment '유저 이메일',
    password   varchar(45)                         not null comment '유저 비밀번호',
    nickname   varchar(45)                         not null comment '유저 닉네임',
    birth      date                                not null comment '출생년도',
    gender     varchar(1)                          not null comment 'M/F',
    created_at timestamp default CURRENT_TIMESTAMP not null comment '유저 생성일',
    updated_at timestamp                           null on update CURRENT_TIMESTAMP comment '유저 수정일'
)
    comment '유저 정보 관리';

INSERT INTO wtm.user (id, email, password, nickname, birth, gender, created_at, updated_at) VALUES (21, 'ssafy@naver.com', 'ssafy1234', 'ssafy', '1997-06-17', 'F', '2021-09-28 16:18:21', '2021-09-28 16:18:21');
INSERT INTO wtm.user (id, email, password, nickname, birth, gender, created_at, updated_at) VALUES (22, 'qwe1234@naver.com', 'qwer1234', 'qwertttt', '2021-09-28', 'M', '2021-09-29 17:36:42', '2021-09-29 17:36:42');
INSERT INTO wtm.user (id, email, password, nickname, birth, gender, created_at, updated_at) VALUES (23, 'qwer@naver.com', 'qwer1234', 'qwerttt', '1995-12-31', 'M', '2021-09-29 18:09:47', '2021-09-29 18:09:47');
INSERT INTO wtm.user (id, email, password, nickname, birth, gender, created_at, updated_at) VALUES (28, 'qqqq@naver.com', 'qqqq1111', 'qqq111', '2021-09-27', 'M', '2021-10-03 21:42:56', '2021-10-03 21:42:56');
INSERT INTO wtm.user (id, email, password, nickname, birth, gender, created_at, updated_at) VALUES (33, 'test1234@naver.com', 'wjdtnqls31^', 'test22', '2021-10-05', 'M', '2021-10-04 21:31:02', '2021-10-05 22:06:46');
INSERT INTO wtm.user (id, email, password, nickname, birth, gender, created_at, updated_at) VALUES (34, 'string12@String.com', 'string1234', 'string', '2021-10-05', 'C', '2021-10-04 22:22:35', '2021-10-05 18:13:39');
INSERT INTO wtm.user (id, email, password, nickname, birth, gender, created_at, updated_at) VALUES (36, 'qwer1@naver.com', 'qwer1234', 'qwer1234', '2021-10-02', 'M', '2021-10-04 22:24:16', '2021-10-04 22:24:16');
INSERT INTO wtm.user (id, email, password, nickname, birth, gender, created_at, updated_at) VALUES (40, 'string1234@String.com', 'string1234', 'string12', '2021-10-04', 'M', '2021-10-04 22:27:57', '2021-10-04 22:53:56');
INSERT INTO wtm.user (id, email, password, nickname, birth, gender, created_at, updated_at) VALUES (43, 'dumb@hotmail.com', 'dumb1234', '멍청이', '1998-03-01', 'M', '2021-10-05 15:08:27', '2021-10-05 15:08:27');
INSERT INTO wtm.user (id, email, password, nickname, birth, gender, created_at, updated_at) VALUES (44, 'aaaa@naver.com', 'aaaa1234', '안농', '2021-10-05', 'F', '2021-10-05 16:01:40', '2021-10-05 16:01:40');
INSERT INTO wtm.user (id, email, password, nickname, birth, gender, created_at, updated_at) VALUES (45, 'ssafy@ssafy.com', 'ssafy1234', 'sssafy', '1997-10-06', 'F', '2021-10-05 19:30:47', '2021-10-05 19:30:47');
INSERT INTO wtm.user (id, email, password, nickname, birth, gender, created_at, updated_at) VALUES (46, 'bbbb@naver.com', 'bbbb1234', 'bbbbbb', '2007-10-09', 'M', '2021-10-06 15:18:01', '2021-10-06 15:18:01');