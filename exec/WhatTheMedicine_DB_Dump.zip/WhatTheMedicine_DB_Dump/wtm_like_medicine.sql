create table like_medicine
(
    id          int auto_increment comment '관심 등록 번호'
        primary key,
    user_id     int                                 not null comment '유저 번호',
    medicine_id varchar(9)                          not null comment '약 번호',
    created_at  timestamp default CURRENT_TIMESTAMP not null comment '등록일자',
    updated_at  timestamp                           null on update CURRENT_TIMESTAMP comment '수정일자',
    constraint FK_like_medicine_medicine_id_medicine_id
        foreign key (medicine_id) references medicine (id)
            on delete cascade,
    constraint FK_like_medicine_user_id_user_id
        foreign key (user_id) references user (id)
            on delete cascade
)
    comment '유저가 즐겨찾는 약 관리';

INSERT INTO wtm.like_medicine (id, user_id, medicine_id, created_at, updated_at) VALUES (2, 21, '196600011', '2021-10-04 03:02:17', '2021-10-04 03:02:17');
INSERT INTO wtm.like_medicine (id, user_id, medicine_id, created_at, updated_at) VALUES (3, 21, '197000053', '2021-10-04 03:02:28', '2021-10-04 03:02:28');
INSERT INTO wtm.like_medicine (id, user_id, medicine_id, created_at, updated_at) VALUES (31, 33, '201500053', '2021-10-05 11:28:20', '2021-10-05 11:28:20');
INSERT INTO wtm.like_medicine (id, user_id, medicine_id, created_at, updated_at) VALUES (35, 44, '196600011', '2021-10-05 16:28:11', '2021-10-05 16:28:11');
INSERT INTO wtm.like_medicine (id, user_id, medicine_id, created_at, updated_at) VALUES (36, 44, '196600012', '2021-10-05 16:28:32', '2021-10-05 16:28:32');
INSERT INTO wtm.like_medicine (id, user_id, medicine_id, created_at, updated_at) VALUES (37, 44, '199901332', '2021-10-05 16:28:48', '2021-10-05 16:28:48');
INSERT INTO wtm.like_medicine (id, user_id, medicine_id, created_at, updated_at) VALUES (39, 23, '199402278', '2021-10-06 16:12:39', '2021-10-06 16:12:39');
INSERT INTO wtm.like_medicine (id, user_id, medicine_id, created_at, updated_at) VALUES (40, 23, '199303109', '2021-10-06 16:39:03', '2021-10-06 16:39:03');